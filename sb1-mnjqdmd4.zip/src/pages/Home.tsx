import React from 'react';
import { Coffee, Users, TrendingUp, Package } from 'lucide-react';
import { Link } from 'react-router-dom';
import VideoCarousel from '../components/VideoCarousel';

const Home = () => {
  return (
    <div className="space-y-8">
      <section className="relative h-[500px] -mt-20 mb-12">
        <div className="absolute inset-0">
          <img
            src="https://images.unsplash.com/photo-1574879948818-1cfda7aa5b1a"
            alt="Interior"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-black bg-opacity-50" />
        </div>
        <div className="relative h-full flex items-center justify-center text-center text-white px-4">
          <div>
            <h1 className="text-5xl font-bold mb-4">Bongji Coffeehouse</h1>
            <p className="text-xl max-w-2xl mx-auto">
              Managing excellence across our network of premium coffee
              establishments
            </p>
          </div>
        </div>
      </section>

      <section className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Link
          to="/employees"
          className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow"
        >
          <Users className="h-8 w-8 text-brown-600 mb-4" />
          <h2 className="text-xl font-semibold mb-2">Employee Management</h2>
          <p className="text-gray-600">Manage staff, Posisi, dan Gajinya.</p>
        </Link>

        <Link
          to="/products"
          className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow"
        >
          <Coffee className="h-8 w-8 text-brown-600 mb-4" />
          <h2 className="text-xl font-semibold mb-2">Product Catalog</h2>
          <p className="text-gray-600">Lihat menu-menu expensive kami.</p>
        </Link>

        <Link
          to="/sales"
          className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow"
        >
          <TrendingUp className="h-8 w-8 text-brown-600 mb-4" />
          <h2 className="text-xl font-semibold mb-2">Sales Analytics</h2>
          <p className="text-gray-600">Peforma dan tingkat penjualan.</p>
        </Link>

        <Link
          to="/inventory"
          className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow"
        >
          <Package className="h-8 w-8 text-brown-600 mb-4" />
          <h2 className="text-xl font-semibold mb-2">Inventory Control</h2>
          <p className="text-gray-600">Monitor stock barang dan supply.</p>
        </Link>
      </section>

      <section className="bg-white rounded-lg shadow-md p-8 mt-8">
        <h2 className="text-2xl font-bold mb-4">Company Overview</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="text-center">
            <div className="text-4xl font-bold text-brown-600 mb-2">15+</div>
            <div className="text-gray-600">Cabang Kami</div>
          </div>
          <div className="text-center">
            <div className="text-4xl font-bold text-brown-600 mb-2">200+</div>
            <div className="text-gray-600">Pekerja yang Berdedikasi</div>
          </div>
          <div className="text-center">
            <div className="text-4xl font-bold text-brown-600 mb-2">50K+</div>
            <div className="text-gray-600">Custommers setiap bulan</div>
          </div>
        </div>
      </section>
      <VideoCarousel />
    </div>
  );
};

export default Home;
