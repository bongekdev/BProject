import React from 'react';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  BarChart,
  Bar,
} from 'recharts';

const monthlySales = [
  { day: '1', sales: 24 },
  { day: '5', sales: 28 },
  { day: '10', sales: 32 },
  { day: '15', sales: 29 },
  { day: '20', sales: 35 },
  { day: '25', sales: 38 },
  { day: '30', sales: 36 },
];

const locationSales = [
  { location: 'Bandung', sales: 80 },
  { location: 'Bali', sales: 72 },
  { location: 'Jakarta', sales: 68 },
  { location: 'Gresik', sales: 55 },
  { location: 'Yogyakarta', sales: 48 },
];

const Sales = () => {
  return (
    <div className="space-y-8">
      <div className="bg-white rounded-lg shadow-md p-6 overflow-x-auto">
        <h1 className="text-2xl font-bold mb-6">Analisa Penjualan</h1>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Monthly Sales Trend */}
          <div>
            <h2 className="text-xl font-semibold mb-4">
              Penjualan Harian (Bulan Ini)
            </h2>
            <LineChart width={500} height={300} data={monthlySales}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="day" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Line
                type="monotone"
                dataKey="sales"
                stroke="#a18072"
                name="Penjualan Harian (Juta)"
              />
            </LineChart>
          </div>

          {/* Location Performance */}
          <div>
            <h2 className="text-xl font-semibold mb-4">Peforma Lokasi</h2>
            <BarChart width={500} height={300} data={locationSales}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis
                dataKey="location"
                angle={0}
                textAnchor="middle"
                height={100}
              />
              <YAxis />
              <Tooltip />
              <Legend />
              <Bar
                dataKey="sales"
                fill="#a18072"
                name="Penjualan Bulanan (Juta)"
              />
            </BarChart>
          </div>
        </div>
      </div>

      {/* Sales Summary */}
      <div className="bg-white rounded-lg shadow-md p-6">
        <h2 className="text-xl font-semibold mb-4">Ringkasan Penjualan</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-brown-50 rounded-lg p-4 text-center">
            <div className="text-2xl font-bold text-brown-600">
              Rp. 328.000.000
            </div>
            <div className="text-gray-600">Total Penjualan Bulanan</div>
          </div>
          <div className="bg-brown-50 rounded-lg p-4 text-center">
            <div className="text-2xl font-bold text-brown-600">
              Rp. 10.933.000
            </div>
            <div className="text-gray-600">Rata-Rata Penjualan Harian</div>
          </div>
          <div className="bg-brown-50 rounded-lg p-4 text-center">
            <div className="text-2xl font-bold text-brown-600">+15.3%</div>
            <div className="text-gray-600">Peningkatan Bulan Ini</div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Sales;
