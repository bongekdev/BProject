import React from 'react';
import { NavLink } from 'react-router-dom';
import { Coffee } from 'lucide-react';

const Navbar = () => {
  return (
    <nav className="fixed top-0 w-full bg-brown-900 text-white shadow-lg z-50">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <NavLink to="/" className="flex items-center space-x-2">
            <Coffee className="h-8 w-8" />
            <span className="text-xl font-bold">Bongji Coffeehouse</span>
          </NavLink>
          
          <div className="hidden md:flex space-x-6">
            <NavLink 
              to="/" 
              className={({ isActive }) => 
                `hover:text-brown-200 transition-colors ${isActive ? 'text-brown-300' : ''}`
              }
            >
              Home
            </NavLink>
            <NavLink 
              to="/employees" 
              className={({ isActive }) => 
                `hover:text-brown-200 transition-colors ${isActive ? 'text-brown-300' : ''}`
              }
            >
              Employees
            </NavLink>
            <NavLink 
              to="/products" 
              className={({ isActive }) => 
                `hover:text-brown-200 transition-colors ${isActive ? 'text-brown-300' : ''}`
              }
            >
              Products
            </NavLink>
            <NavLink 
              to="/sales" 
              className={({ isActive }) => 
                `hover:text-brown-200 transition-colors ${isActive ? 'text-brown-300' : ''}`
              }
            >
              Sales
            </NavLink>
            <NavLink 
              to="/inventory" 
              className={({ isActive }) => 
                `hover:text-brown-200 transition-colors ${isActive ? 'text-brown-300' : ''}`
              }
            >
              Inventory
            </NavLink>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;