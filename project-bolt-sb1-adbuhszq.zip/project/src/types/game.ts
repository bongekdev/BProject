export interface Position {
  x: number;
  y: number;
}

export interface Player {
  position: Position;
  health: number;
  hunger: number;
  thirst: number;
  inventory: Inventory;
  direction: 'up' | 'down' | 'left' | 'right';
  isMoving: boolean;
}

export interface Inventory {
  wood: number;
  stone: number;
  berries: number;
  water: number;
  tools: Tool[];
}

export interface Tool {
  name: string;
  durability: number;
  type: 'axe' | 'pickaxe' | 'container';
}

export interface Resource {
  type: 'tree' | 'rock' | 'berry_bush' | 'water_source';
  position: Position;
  amount: number;
  maxAmount: number;
}

export interface Animal {
  type: 'rabbit' | 'wolf' | 'deer';
  position: Position;
  direction: Position;
  speed: number;
  hostile: boolean;
  health: number;
}

export interface GameState {
  player: Player;
  resources: Resource[];
  animals: Animal[];
  timeOfDay: number; // 0-24 hours
  day: number;
  weather: 'clear' | 'rain' | 'storm';
  gameOver: boolean;
  paused: boolean;
}

export interface Recipe {
  name: string;
  requires: { [key: string]: number };
  produces: { [key: string]: number };
  category: 'tools' | 'shelter' | 'food';
}