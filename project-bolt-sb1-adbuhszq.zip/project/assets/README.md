# Assets Folder

Folder ini akan berisi asset game seperti gambar dan suara.

## Struktur Folder
```
assets/
├── images/          # Sprite dan gambar game
└── sounds/          # Efek suara dan musik
```

## Catatan
Game akan otomatis membuat sprite secara prosedural jika file asset tidak tersedia, jadi game tetap bisa berjalan tanpa file eksternal.

Jika Anda ingin menambahkan asset kustom:
- Letakkan file gambar (.png, .jpg) di folder `images/`
- Letakkan file suara (.wav, .ogg) di folder `sounds/`
- Update kode di `AssetManager` untuk memuat file tersebut