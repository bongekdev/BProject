# Wilderness Survival Game - Enhanced Edition

Sebuah game survival lengkap yang dibangun dengan Pygame, menampilkan grafik yang menarik, efek suara, dan mekanik gameplay yang mendalam.

## 🎮 Fitur Game

### Mekanik Survival Inti
- **Sistem Survival Lengkap**: Kelola kesehatan, kelaparan, kehausan, dan energi
- **Pengumpulan Sumber Daya**: Kumpulkan kayu dari pohon, batu dari bebatuan, berry dari semak, dan air dari sumber air
- **Sistem Crafting**: Buat alat seperti kapak, beliung, dan tombak
- **Sistem Berburu**: Berburu kelinci dan rusa, bertahan dari serangan serigala
- **Siklus Siang/Malam**: Perkembangan waktu mempengaruhi gameplay

### Dunia Game
- **Dunia Terbuka Besar**: Dunia berukuran 3200x2400 pixel dengan kamera yang mengikuti
- **Generasi Prosedural**: Penempatan acak sumber daya dan hewan
- **Multiple Biomes**: Pohon, bebatuan, semak berry, dan sumber air tersebar di seluruh dunia

### Hewan
- **Kelinci**: Damai, memberikan daging saat diburu
- **Rusa**: Mangsa yang lebih besar, memberikan lebih banyak daging
- **Serigala**: Predator yang agresif dan menyerang pemain

### Alat & Crafting
- **Kapak**: Meningkatkan efisiensi pengumpulan kayu
- **Beliung**: Meningkatkan efisiensi pengumpulan batu
- **Tombak**: Meningkatkan damage saat berburu

## 🎨 Fitur Visual & Audio

### Grafik
- **Sprite Kustom**: Semua elemen game menggunakan sprite yang dibuat khusus
- **Animasi**: Karakter dan hewan memiliki animasi sederhana
- **UI yang Menarik**: Interface pengguna dengan ikon dan bar status yang jelas
- **Efek Visual**: Bar kesehatan untuk hewan yang terluka, indikator jumlah sumber daya

### Audio
- **Efek Suara**: Suara untuk harvesting, crafting, menyerang, terluka, makan, dan berjalan
- **Sistem Audio Dinamis**: Suara yang responsif terhadap aksi pemain

## 🚀 Instalasi & Setup

1. **Install Python 3.7+**
   ```bash
   python --version
   ```

2. **Install Pygame**
   ```bash
   pip install pygame
   ```

3. **Jalankan Game**
   ```bash
   python main.py
   ```

## 🎮 Kontrol

### Pergerakan
- **WASD** atau **Arrow Keys**: Gerakkan pemain
- **Mouse**: Tidak digunakan (hanya keyboard)

### Aksi
- **E**: Kumpulkan sumber daya terdekat
- **F**: Serang hewan terdekat
- **I**: Toggle tampilan inventory
- **C**: Toggle menu crafting
- **1**: Makan berry (mengembalikan kelaparan)
- **2**: Makan daging (mengembalikan lebih banyak kelaparan)
- **3**: Minum air (mengembalikan kehausan)

### Crafting (saat menu crafting terbuka)
- **Q**: Craft Kapak
- **W**: Craft Beliung
- **E**: Craft Tombak

### Kontrol Menu
- **SPACE**: Mulai game dari menu utama
- **ESC**: Pause/unpause game
- **Q**: Keluar dari pause atau game over screen
- **R**: Restart dari game over screen

## 🎯 Tips Gameplay

### Strategi Survival
1. **Kumpulkan Sumber Daya Awal**: Kumpulkan kayu dan batu untuk membuat alat
2. **Craft Alat**: Kapak dan beliung meningkatkan efisiensi pengumpulan
3. **Berburu untuk Makanan**: Hewan memberikan daging yang mengembalikan lebih banyak kelaparan daripada berry
4. **Tetap Terhidrasi**: Sumber air terbatas, kumpulkan botol air
5. **Hindari Serigala**: Mereka agresif dan memberikan damage yang signifikan

### Manajemen Sumber Daya
- **Kayu**: Dikumpulkan dari pohon, digunakan untuk crafting alat
- **Batu**: Dikumpulkan dari bebatuan, digunakan untuk crafting alat
- **Berry**: Dikumpulkan dari semak, mengembalikan kelaparan
- **Air**: Dikumpulkan dari sumber air, mengembalikan kehausan
- **Daging**: Diperoleh dengan berburu hewan, mengembalikan kelaparan secara efisien

### Resep Crafting
- **Kapak**: 3 Kayu + 2 Batu
- **Beliung**: 2 Kayu + 3 Batu
- **Tombak**: 2 Kayu + 1 Batu

## ⚙️ Mekanik Game

### Sistem Kesehatan
- Kesehatan berkurang saat diserang serigala
- Kesehatan berkurang saat kelaparan atau kehausan mencapai nol
- Game over saat kesehatan mencapai nol

### Kelaparan & Kehausan
- Keduanya berkurang seiring waktu
- Kelaparan berkurang lebih lambat daripada kehausan
- Dapat dipulihkan dengan mengonsumsi makanan dan air

### Sistem Energi
- Energi berkurang saat bergerak
- Regenerasi saat berdiam diri
- Mempengaruhi kecepatan gerakan saat rendah

### Sistem Waktu
- Siklus siang/malam berlangsung otomatis
- Setiap detik real sama dengan satu jam game
- Counter hari melacak progress survival

## 🔧 Detail Teknis

### Performa
- **60 FPS** target framerate
- **Rendering Efisien** dengan camera culling
- **Deteksi Collision Optimal** hanya untuk objek terdekat

### Generasi Dunia
- **200 Pohon** ditempatkan secara acak
- **100 Formasi Batu** tersebar di seluruh dunia
- **80 Semak Berry** untuk pengumpulan makanan
- **25 Sumber Air** untuk hidrasi
- **40 Hewan** dari berbagai jenis

### Struktur Kode
- **Desain Object-oriented** dengan pemisahan class yang jelas
- **Manajemen Game State** untuk berbagai layar
- **Sistem Modular** untuk ekspansi yang mudah
- **Event Handling Bersih** untuk kontrol yang responsif

## 🎨 Sistem Asset

### Manajemen Grafik
- **AssetManager Class**: Mengelola semua sprite dan gambar
- **Sprite Generation**: Membuat sprite secara prosedural jika file tidak tersedia
- **Fallback System**: Menggunakan warna solid jika sprite gagal dimuat

### Sistem Audio
- **Sound Effects**: Efek suara yang dibuat secara prosedural
- **Audio Feedback**: Suara responsif untuk setiap aksi
- **Error Handling**: Sistem audio tetap berjalan meski ada error

## 🚀 Mengembangkan Game

Kode dirancang untuk modifikasi dan ekspansi yang mudah:

### Menambah Sumber Daya Baru
1. Tambahkan tipe sumber daya baru ke class `Resource`
2. Update method `get_max_amount()` dan `harvest()`
3. Tambahkan ke generasi dunia di `generate_world()`
4. Buat sprite baru di `AssetManager`

### Menambah Hewan Baru
1. Tambahkan tipe hewan baru ke class `Animal`
2. Update method health, speed, dan behavior
3. Tambahkan ke generasi hewan
4. Buat sprite baru di `create_animal_sprite()`

### Menambah Item/Alat Baru
1. Tambahkan ke dictionary `Inventory.items`
2. Buat resep crafting di `craft_item()`
3. Update method tampilan UI
4. Buat sprite alat baru

### Menambah Mekanik Game Baru
- Sistem cuaca (sudah diimplementasi sebagian)
- Sistem building/shelter
- Rantai crafting yang lebih kompleks
- Sistem progression skill
- Fungsi save/load

## 🐛 Troubleshooting

### Masalah Umum
1. **Pygame tidak ditemukan**: Install dengan `pip install pygame`
2. **Game berjalan lambat**: Kurangi ukuran dunia atau jumlah entitas
3. **Kontrol tidak responsif**: Pastikan window game memiliki focus
4. **Suara tidak keluar**: Normal, sistem audio menggunakan fallback jika ada error

### Optimasi Performa
- Kurangi `world_width` dan `world_height` untuk komputer yang lebih lambat
- Kurangi jumlah sumber daya/hewan di `generate_world()`
- Turunkan konstanta `FPS` jika diperlukan

## 📝 Changelog Enhanced Edition

### Fitur Baru
- ✅ Sistem grafik lengkap dengan sprite kustom
- ✅ Efek suara untuk semua aksi
- ✅ UI yang lebih menarik dengan ikon
- ✅ Animasi sederhana untuk karakter
- ✅ Sistem kamera yang smooth
- ✅ Bar kesehatan untuk hewan
- ✅ Quick inventory display
- ✅ Menu yang lebih menarik
- ✅ Statistik game over yang detail

### Perbaikan
- ✅ Performa rendering yang lebih baik
- ✅ Kontrol yang lebih responsif
- ✅ Balance gameplay yang lebih baik
- ✅ Error handling yang lebih robust

## 📄 Lisensi

Game ini disediakan untuk tujuan edukasi dan hiburan. Silakan modifikasi dan kembangkan sesuai kebutuhan!

---

**Selamat bermain dan bertahan hidup di alam liar! 🌲🦌🔥**