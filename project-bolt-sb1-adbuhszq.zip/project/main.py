import pygame
import sys
import random
import math
import json
import os
from enum import Enum
from dataclasses import dataclass
from typing import List, Dict, Tuple, Optional

# Initialize Pygame
pygame.init()
pygame.mixer.init()

# Constants
SCREEN_WIDTH = 1200
SCREEN_HEIGHT = 800
FPS = 60
TILE_SIZE = 64

# Colors (fallback if images fail to load)
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
GREEN = (34, 139, 34)
BROWN = (139, 69, 19)
BLUE = (30, 144, 255)
RED = (220, 20, 60)
YELLOW = (255, 215, 0)
GRAY = (128, 128, 128)
DARK_GREEN = (0, 100, 0)
LIGHT_BLUE = (173, 216, 230)

class GameState(Enum):
    MENU = "menu"
    PLAYING = "playing"
    PAUSED = "paused"
    INVENTORY = "inventory"
    CRAFTING = "crafting"
    GAME_OVER = "game_over"

@dataclass
class Position:
    x: float
    y: float
    
    def distance_to(self, other: 'Position') -> float:
        return math.sqrt((self.x - other.x)**2 + (self.y - other.y)**2)

class AssetManager:
    def __init__(self):
        self.images = {}
        self.sounds = {}
        self.load_assets()
    
    def create_colored_surface(self, color, size=(TILE_SIZE, TILE_SIZE)):
        """Create a colored surface as fallback"""
        surface = pygame.Surface(size)
        surface.fill(color)
        return surface
    
    def create_player_sprite(self):
        """Create player sprite"""
        surface = pygame.Surface((TILE_SIZE, TILE_SIZE), pygame.SRCALPHA)
        # Draw a simple character
        pygame.draw.circle(surface, (255, 220, 177), (TILE_SIZE//2, TILE_SIZE//3), 12)  # Head
        pygame.draw.rect(surface, (0, 100, 200), (TILE_SIZE//2-8, TILE_SIZE//3+8, 16, 20))  # Body
        pygame.draw.rect(surface, (139, 69, 19), (TILE_SIZE//2-6, TILE_SIZE//3+28, 5, 15))  # Left leg
        pygame.draw.rect(surface, (139, 69, 19), (TILE_SIZE//2+1, TILE_SIZE//3+28, 5, 15))  # Right leg
        pygame.draw.rect(surface, (255, 220, 177), (TILE_SIZE//2-12, TILE_SIZE//3+12, 8, 3))  # Left arm
        pygame.draw.rect(surface, (255, 220, 177), (TILE_SIZE//2+4, TILE_SIZE//3+12, 8, 3))  # Right arm
        return surface
    
    def create_tree_sprite(self):
        """Create tree sprite"""
        surface = pygame.Surface((TILE_SIZE, TILE_SIZE), pygame.SRCALPHA)
        # Tree trunk
        pygame.draw.rect(surface, (101, 67, 33), (TILE_SIZE//2-6, TILE_SIZE//2+10, 12, 20))
        # Tree crown
        pygame.draw.circle(surface, (34, 139, 34), (TILE_SIZE//2, TILE_SIZE//2-5), 20)
        pygame.draw.circle(surface, (0, 100, 0), (TILE_SIZE//2-8, TILE_SIZE//2-8), 15)
        pygame.draw.circle(surface, (0, 100, 0), (TILE_SIZE//2+8, TILE_SIZE//2-8), 15)
        return surface
    
    def create_rock_sprite(self):
        """Create rock sprite"""
        surface = pygame.Surface((TILE_SIZE, TILE_SIZE), pygame.SRCALPHA)
        # Main rock
        pygame.draw.ellipse(surface, (105, 105, 105), (10, 20, 44, 30))
        pygame.draw.ellipse(surface, (128, 128, 128), (8, 18, 40, 28))
        # Smaller rocks
        pygame.draw.ellipse(surface, (90, 90, 90), (35, 35, 20, 15))
        pygame.draw.ellipse(surface, (110, 110, 110), (15, 40, 15, 12))
        return surface
    
    def create_berry_bush_sprite(self):
        """Create berry bush sprite"""
        surface = pygame.Surface((TILE_SIZE, TILE_SIZE), pygame.SRCALPHA)
        # Bush base
        pygame.draw.ellipse(surface, (34, 139, 34), (8, 25, 48, 30))
        pygame.draw.ellipse(surface, (0, 100, 0), (12, 20, 40, 25))
        # Berries
        for _ in range(8):
            x = random.randint(15, 45)
            y = random.randint(25, 40)
            pygame.draw.circle(surface, (220, 20, 60), (x, y), 3)
        return surface
    
    def create_water_sprite(self):
        """Create water source sprite"""
        surface = pygame.Surface((TILE_SIZE, TILE_SIZE), pygame.SRCALPHA)
        # Water
        pygame.draw.ellipse(surface, (30, 144, 255), (5, 15, 54, 40))
        pygame.draw.ellipse(surface, (173, 216, 230), (8, 18, 48, 34))
        # Ripples
        pygame.draw.ellipse(surface, (100, 149, 237), (15, 25, 30, 20), 2)
        pygame.draw.ellipse(surface, (100, 149, 237), (20, 30, 20, 12), 2)
        return surface
    
    def create_animal_sprite(self, animal_type):
        """Create animal sprites"""
        surface = pygame.Surface((TILE_SIZE, TILE_SIZE), pygame.SRCALPHA)
        
        if animal_type == 'rabbit':
            # Rabbit body
            pygame.draw.ellipse(surface, WHITE, (20, 30, 24, 20))
            # Head
            pygame.draw.circle(surface, WHITE, (32, 25), 8)
            # Ears
            pygame.draw.ellipse(surface, WHITE, (28, 15, 4, 12))
            pygame.draw.ellipse(surface, WHITE, (32, 15, 4, 12))
            # Eye
            pygame.draw.circle(surface, BLACK, (30, 23), 2)
            # Tail
            pygame.draw.circle(surface, WHITE, (45, 35), 4)
            
        elif animal_type == 'deer':
            # Deer body
            pygame.draw.ellipse(surface, BROWN, (15, 25, 35, 25))
            # Head
            pygame.draw.ellipse(surface, BROWN, (35, 20, 15, 12))
            # Legs
            for x in [18, 25, 35, 42]:
                pygame.draw.rect(surface, BROWN, (x, 45, 3, 12))
            # Antlers
            pygame.draw.line(surface, (101, 67, 33), (42, 18), (38, 12), 2)
            pygame.draw.line(surface, (101, 67, 33), (42, 18), (46, 12), 2)
            pygame.draw.line(surface, (101, 67, 33), (45, 18), (41, 12), 2)
            pygame.draw.line(surface, (101, 67, 33), (45, 18), (49, 12), 2)
            
        elif animal_type == 'wolf':
            # Wolf body
            pygame.draw.ellipse(surface, (64, 64, 64), (12, 28, 40, 22))
            # Head
            pygame.draw.ellipse(surface, (64, 64, 64), (35, 22, 18, 15))
            # Snout
            pygame.draw.ellipse(surface, (48, 48, 48), (45, 26, 8, 6))
            # Ears
            pygame.draw.polygon(surface, (64, 64, 64), [(38, 22), (42, 15), (46, 22)])
            pygame.draw.polygon(surface, (64, 64, 64), [(46, 22), (50, 15), (54, 22)])
            # Eyes
            pygame.draw.circle(surface, RED, (40, 25), 2)
            pygame.draw.circle(surface, RED, (46, 25), 2)
            # Legs
            for x in [15, 22, 35, 42]:
                pygame.draw.rect(surface, (64, 64, 64), (x, 45, 4, 15))
            # Tail
            pygame.draw.ellipse(surface, (64, 64, 64), (8, 32, 12, 8))
        
        return surface
    
    def create_tool_sprite(self, tool_type):
        """Create tool sprites"""
        surface = pygame.Surface((32, 32), pygame.SRCALPHA)
        
        if tool_type == 'axe':
            # Handle
            pygame.draw.rect(surface, (101, 67, 33), (14, 8, 4, 20))
            # Blade
            pygame.draw.polygon(surface, (169, 169, 169), [(12, 8), (20, 8), (18, 15), (14, 15)])
            
        elif tool_type == 'pickaxe':
            # Handle
            pygame.draw.rect(surface, (101, 67, 33), (14, 8, 4, 20))
            # Pick
            pygame.draw.polygon(surface, (169, 169, 169), [(10, 10), (22, 10), (16, 6)])
            
        elif tool_type == 'spear':
            # Handle
            pygame.draw.rect(surface, (101, 67, 33), (14, 12, 4, 16))
            # Spear tip
            pygame.draw.polygon(surface, (169, 169, 169), [(14, 4), (18, 4), (16, 12)])
        
        return surface
    
    def load_assets(self):
        """Load all game assets"""
        # Create directories if they don't exist
        os.makedirs('assets/images', exist_ok=True)
        os.makedirs('assets/sounds', exist_ok=True)
        
        # Load/Create images
        self.images['player'] = self.create_player_sprite()
        self.images['tree'] = self.create_tree_sprite()
        self.images['rock'] = self.create_rock_sprite()
        self.images['berry_bush'] = self.create_berry_bush_sprite()
        self.images['water_source'] = self.create_water_sprite()
        
        # Animal sprites
        self.images['rabbit'] = self.create_animal_sprite('rabbit')
        self.images['deer'] = self.create_animal_sprite('deer')
        self.images['wolf'] = self.create_animal_sprite('wolf')
        
        # Tool sprites
        self.images['axe'] = self.create_tool_sprite('axe')
        self.images['pickaxe'] = self.create_tool_sprite('pickaxe')
        self.images['spear'] = self.create_tool_sprite('spear')
        
        # Background
        self.images['grass'] = self.create_colored_surface((34, 139, 34))
        
        # UI elements
        self.images['wood_icon'] = self.create_colored_surface((101, 67, 33), (24, 24))
        self.images['stone_icon'] = self.create_colored_surface((128, 128, 128), (24, 24))
        self.images['berries_icon'] = self.create_colored_surface((220, 20, 60), (24, 24))
        self.images['water_icon'] = self.create_colored_surface((30, 144, 255), (24, 24))
        self.images['meat_icon'] = self.create_colored_surface((139, 69, 19), (24, 24))
        
        # Try to load sounds (create silent sounds if files don't exist)
        self.create_sounds()
    
    def create_sounds(self):
        """Create sound effects"""
        try:
            # Create simple sound effects using pygame
            self.sounds['harvest'] = self.create_sound_effect(440, 0.1)  # A note
            self.sounds['craft'] = self.create_sound_effect(523, 0.2)    # C note
            self.sounds['attack'] = self.create_sound_effect(220, 0.15)  # Lower A
            self.sounds['hurt'] = self.create_sound_effect(165, 0.3)     # Low note
            self.sounds['eat'] = self.create_sound_effect(660, 0.1)      # High E
            self.sounds['walk'] = self.create_sound_effect(330, 0.05)    # Soft step
        except:
            # If sound creation fails, create dummy sounds
            for sound_name in ['harvest', 'craft', 'attack', 'hurt', 'eat', 'walk']:
                self.sounds[sound_name] = None
    
    def create_sound_effect(self, frequency, duration):
        """Create a simple beep sound effect"""
        sample_rate = 22050
        frames = int(duration * sample_rate)
        arr = []
        for i in range(frames):
            wave = 4096 * math.sin(frequency * 2 * math.pi * i / sample_rate)
            arr.append([int(wave), int(wave)])
        sound = pygame.sndarray.make_sound(pygame.array.array('i', arr))
        return sound
    
    def play_sound(self, sound_name):
        """Play a sound effect"""
        if sound_name in self.sounds and self.sounds[sound_name]:
            try:
                self.sounds[sound_name].play()
            except:
                pass  # Ignore sound errors
    
    def get_image(self, name):
        """Get an image by name"""
        return self.images.get(name, self.create_colored_surface(WHITE))

class Item:
    def __init__(self, name: str, item_type: str, value: int = 1):
        self.name = name
        self.type = item_type
        self.value = value

class Inventory:
    def __init__(self):
        self.items: Dict[str, int] = {
            'wood': 0,
            'stone': 0,
            'berries': 0,
            'water': 0,
            'meat': 0,
            'axe': 0,
            'pickaxe': 0,
            'spear': 0
        }
        self.max_capacity = 50
    
    def add_item(self, item_name: str, amount: int = 1) -> bool:
        current_total = sum(self.items.values())
        if current_total + amount <= self.max_capacity:
            self.items[item_name] = self.items.get(item_name, 0) + amount
            return True
        return False
    
    def remove_item(self, item_name: str, amount: int = 1) -> bool:
        if self.items.get(item_name, 0) >= amount:
            self.items[item_name] -= amount
            return True
        return False
    
    def has_item(self, item_name: str, amount: int = 1) -> bool:
        return self.items.get(item_name, 0) >= amount

class Player:
    def __init__(self, x: float, y: float):
        self.position = Position(x, y)
        self.health = 100
        self.max_health = 100
        self.hunger = 100
        self.thirst = 100
        self.energy = 100
        self.inventory = Inventory()
        self.speed = 4
        self.direction = 0  # 0=right, 1=down, 2=left, 3=up
        self.is_moving = False
        self.last_damage_time = 0
        self.animation_frame = 0
        self.last_step_sound = 0
        
    def move(self, dx: float, dy: float, world_width: int, world_height: int, assets: AssetManager):
        new_x = max(0, min(world_width - TILE_SIZE, self.position.x + dx))
        new_y = max(0, min(world_height - TILE_SIZE, self.position.y + dy))
        
        if new_x != self.position.x or new_y != self.position.y:
            self.position.x = new_x
            self.position.y = new_y
            self.is_moving = True
            self.energy = max(0, self.energy - 0.1)
            self.animation_frame += 1
            
            # Play walking sound occasionally
            current_time = pygame.time.get_ticks()
            if current_time - self.last_step_sound > 300:
                assets.play_sound('walk')
                self.last_step_sound = current_time
        else:
            self.is_moving = False
    
    def update_stats(self, dt: float):
        # Decrease hunger and thirst over time
        self.hunger = max(0, self.hunger - 2 * dt)
        self.thirst = max(0, self.thirst - 3 * dt)
        
        # Regenerate energy when not moving
        if not self.is_moving:
            self.energy = min(100, self.energy + 10 * dt)
        
        # Health decreases if hungry or thirsty
        if self.hunger <= 0 or self.thirst <= 0:
            self.health = max(0, self.health - 5 * dt)
    
    def eat(self, food_type: str, assets: AssetManager):
        if food_type == 'berries' and self.inventory.has_item('berries'):
            self.inventory.remove_item('berries')
            self.hunger = min(100, self.hunger + 20)
            assets.play_sound('eat')
        elif food_type == 'meat' and self.inventory.has_item('meat'):
            self.inventory.remove_item('meat')
            self.hunger = min(100, self.hunger + 40)
            assets.play_sound('eat')
    
    def drink(self, assets: AssetManager):
        if self.inventory.has_item('water'):
            self.inventory.remove_item('water')
            self.thirst = min(100, self.thirst + 30)
            assets.play_sound('eat')

class Resource:
    def __init__(self, x: float, y: float, resource_type: str):
        self.position = Position(x, y)
        self.type = resource_type
        self.amount = self.get_max_amount()
        self.max_amount = self.amount
        self.respawn_time = 0
        
    def get_max_amount(self) -> int:
        amounts = {'tree': 5, 'rock': 3, 'berry_bush': 8, 'water_source': 999}
        return amounts.get(self.type, 1)
    
    def harvest(self, tool: str = None) -> Tuple[str, int]:
        if self.amount <= 0:
            return "", 0
            
        harvest_map = {
            'tree': ('wood', 2 if tool == 'axe' else 1),
            'rock': ('stone', 2 if tool == 'pickaxe' else 1),
            'berry_bush': ('berries', 2),
            'water_source': ('water', 1)
        }
        
        item, base_amount = harvest_map.get(self.type, ("", 0))
        if item:
            harvest_amount = min(base_amount, self.amount)
            self.amount -= harvest_amount
            return item, harvest_amount
        return "", 0

class Animal:
    def __init__(self, x: float, y: float, animal_type: str):
        self.position = Position(x, y)
        self.type = animal_type
        self.health = self.get_max_health()
        self.speed = self.get_speed()
        self.direction = random.uniform(0, 2 * math.pi)
        self.hostile = animal_type == 'wolf'
        self.last_direction_change = 0
        self.target_player = False
        self.animation_frame = 0
        
    def get_max_health(self) -> int:
        health_map = {'rabbit': 20, 'deer': 40, 'wolf': 60}
        return health_map.get(self.type, 20)
    
    def get_speed(self) -> float:
        speed_map = {'rabbit': 2.5, 'deer': 2.0, 'wolf': 3.5}
        return speed_map.get(self.type, 2.0)
    
    def update(self, dt: float, player_pos: Position, world_width: int, world_height: int):
        current_time = pygame.time.get_ticks()
        
        # Change direction occasionally
        if current_time - self.last_direction_change > random.randint(2000, 5000):
            self.direction = random.uniform(0, 2 * math.pi)
            self.last_direction_change = current_time
        
        # Wolves chase player if close
        if self.type == 'wolf':
            distance_to_player = self.position.distance_to(player_pos)
            if distance_to_player < 200:
                self.target_player = True
                angle_to_player = math.atan2(player_pos.y - self.position.y, 
                                           player_pos.x - self.position.x)
                self.direction = angle_to_player
            elif distance_to_player > 300:
                self.target_player = False
        
        # Move
        dx = math.cos(self.direction) * self.speed * dt * 60
        dy = math.sin(self.direction) * self.speed * dt * 60
        
        new_x = max(0, min(world_width - TILE_SIZE, self.position.x + dx))
        new_y = max(0, min(world_height - TILE_SIZE, self.position.y + dy))
        
        self.position.x = new_x
        self.position.y = new_y
        self.animation_frame += 1

class Game:
    def __init__(self):
        self.screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
        pygame.display.set_caption("Wilderness Survival - Enhanced Edition")
        self.clock = pygame.time.Clock()
        self.font = pygame.font.Font(None, 24)
        self.big_font = pygame.font.Font(None, 48)
        self.small_font = pygame.font.Font(None, 18)
        
        # Load assets
        self.assets = AssetManager()
        
        # Game state
        self.state = GameState.MENU
        self.world_width = 3200
        self.world_height = 2400
        self.camera_x = 0
        self.camera_y = 0
        
        # Game objects
        self.player = Player(self.world_width // 2, self.world_height // 2)
        self.resources: List[Resource] = []
        self.animals: List[Animal] = []
        
        # Game variables
        self.day = 1
        self.time_of_day = 12.0  # 0-24 hours
        self.weather = 'clear'
        self.selected_item = 'wood'
        
        # UI
        self.show_inventory = False
        self.show_crafting = False
        
        self.generate_world()
    
    def generate_world(self):
        # Generate trees
        for _ in range(200):
            x = random.randint(0, self.world_width - TILE_SIZE)
            y = random.randint(0, self.world_height - TILE_SIZE)
            self.resources.append(Resource(x, y, 'tree'))
        
        # Generate rocks
        for _ in range(100):
            x = random.randint(0, self.world_width - TILE_SIZE)
            y = random.randint(0, self.world_height - TILE_SIZE)
            self.resources.append(Resource(x, y, 'rock'))
        
        # Generate berry bushes
        for _ in range(80):
            x = random.randint(0, self.world_width - TILE_SIZE)
            y = random.randint(0, self.world_height - TILE_SIZE)
            self.resources.append(Resource(x, y, 'berry_bush'))
        
        # Generate water sources
        for _ in range(25):
            x = random.randint(0, self.world_width - TILE_SIZE)
            y = random.randint(0, self.world_height - TILE_SIZE)
            self.resources.append(Resource(x, y, 'water_source'))
        
        # Generate animals
        for _ in range(40):
            x = random.randint(0, self.world_width - TILE_SIZE)
            y = random.randint(0, self.world_height - TILE_SIZE)
            animal_type = random.choice(['rabbit', 'rabbit', 'deer', 'wolf'])  # More rabbits
            self.animals.append(Animal(x, y, animal_type))
    
    def update_camera(self):
        # Center camera on player with smooth following
        target_x = self.player.position.x - SCREEN_WIDTH // 2
        target_y = self.player.position.y - SCREEN_HEIGHT // 2
        
        # Smooth camera movement
        self.camera_x += (target_x - self.camera_x) * 0.1
        self.camera_y += (target_y - self.camera_y) * 0.1
        
        # Keep camera within world bounds
        self.camera_x = max(0, min(self.world_width - SCREEN_WIDTH, self.camera_x))
        self.camera_y = max(0, min(self.world_height - SCREEN_HEIGHT, self.camera_y))
    
    def handle_input(self):
        keys = pygame.key.get_pressed()
        
        if self.state == GameState.PLAYING:
            # Movement
            dx = dy = 0
            if keys[pygame.K_LEFT] or keys[pygame.K_a]:
                dx = -self.player.speed
                self.player.direction = 2
            if keys[pygame.K_RIGHT] or keys[pygame.K_d]:
                dx = self.player.speed
                self.player.direction = 0
            if keys[pygame.K_UP] or keys[pygame.K_w]:
                dy = -self.player.speed
                self.player.direction = 3
            if keys[pygame.K_DOWN] or keys[pygame.K_s]:
                dy = self.player.speed
                self.player.direction = 1
            
            if dx != 0 or dy != 0:
                self.player.move(dx, dy, self.world_width, self.world_height, self.assets)
        
        # Handle events
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return False
            
            if event.type == pygame.KEYDOWN:
                if self.state == GameState.MENU:
                    if event.key == pygame.K_SPACE:
                        self.state = GameState.PLAYING
                
                elif self.state == GameState.PLAYING:
                    if event.key == pygame.K_i:
                        self.show_inventory = not self.show_inventory
                    elif event.key == pygame.K_c:
                        self.show_crafting = not self.show_crafting
                    elif event.key == pygame.K_e:
                        self.harvest_nearby()
                    elif event.key == pygame.K_f:
                        self.attack_nearby()
                    elif event.key == pygame.K_1:
                        self.player.eat('berries', self.assets)
                    elif event.key == pygame.K_2:
                        self.player.eat('meat', self.assets)
                    elif event.key == pygame.K_3:
                        self.player.drink(self.assets)
                    elif event.key == pygame.K_q:
                        if self.show_crafting:
                            self.craft_item('axe')
                    elif event.key == pygame.K_w and self.show_crafting:
                        self.craft_item('pickaxe')
                    elif event.key == pygame.K_e and self.show_crafting:
                        self.craft_item('spear')
                    elif event.key == pygame.K_ESCAPE:
                        self.state = GameState.PAUSED
                
                elif self.state == GameState.PAUSED:
                    if event.key == pygame.K_ESCAPE:
                        self.state = GameState.PLAYING
                    elif event.key == pygame.K_q:
                        return False
                
                elif self.state == GameState.GAME_OVER:
                    if event.key == pygame.K_r:
                        self.restart_game()
                    elif event.key == pygame.K_q:
                        return False
        
        return True
    
    def harvest_nearby(self):
        player_rect = pygame.Rect(self.player.position.x, self.player.position.y, TILE_SIZE, TILE_SIZE)
        
        for resource in self.resources:
            resource_rect = pygame.Rect(resource.position.x, resource.position.y, TILE_SIZE, TILE_SIZE)
            if player_rect.colliderect(resource_rect) and resource.amount > 0:
                # Determine tool
                tool = None
                if resource.type == 'tree' and self.player.inventory.has_item('axe'):
                    tool = 'axe'
                elif resource.type == 'rock' and self.player.inventory.has_item('pickaxe'):
                    tool = 'pickaxe'
                
                item, amount = resource.harvest(tool)
                if item and amount > 0:
                    if self.player.inventory.add_item(item, amount):
                        self.assets.play_sound('harvest')
                break
    
    def attack_nearby(self):
        player_rect = pygame.Rect(self.player.position.x, self.player.position.y, TILE_SIZE, TILE_SIZE)
        
        for animal in self.animals[:]:  # Copy list to avoid modification during iteration
            animal_rect = pygame.Rect(animal.position.x, animal.position.y, TILE_SIZE, TILE_SIZE)
            if player_rect.colliderect(animal_rect):
                damage = 40 if self.player.inventory.has_item('spear') else 20
                animal.health -= damage
                self.assets.play_sound('attack')
                
                if animal.health <= 0:
                    # Animal dies, drop meat
                    meat_amount = 3 if animal.type == 'deer' else 2 if animal.type == 'wolf' else 1
                    self.player.inventory.add_item('meat', meat_amount)
                    self.animals.remove(animal)
                break
    
    def craft_item(self, item_name: str) -> bool:
        recipes = {
            'axe': {'wood': 3, 'stone': 2},
            'pickaxe': {'wood': 2, 'stone': 3},
            'spear': {'wood': 2, 'stone': 1}
        }
        
        if item_name in recipes:
            recipe = recipes[item_name]
            # Check if player has required materials
            for material, amount in recipe.items():
                if not self.player.inventory.has_item(material, amount):
                    return False
            
            # Remove materials and add item
            for material, amount in recipe.items():
                self.player.inventory.remove_item(material, amount)
            self.player.inventory.add_item(item_name, 1)
            self.assets.play_sound('craft')
            return True
        return False
    
    def update(self, dt: float):
        if self.state == GameState.PLAYING:
            # Update player
            self.player.update_stats(dt)
            
            # Update animals
            for animal in self.animals:
                animal.update(dt, self.player.position, self.world_width, self.world_height)
                
                # Check wolf attacks
                if animal.type == 'wolf' and animal.target_player:
                    distance = animal.position.distance_to(self.player.position)
                    if distance < 50:
                        current_time = pygame.time.get_ticks()
                        if current_time - self.player.last_damage_time > 1500:  # 1.5 second cooldown
                            self.player.health -= 20
                            self.player.last_damage_time = current_time
                            self.assets.play_sound('hurt')
            
            # Update time
            self.time_of_day += dt * 12  # Slower day/night cycle
            if self.time_of_day >= 24:
                self.time_of_day = 0
                self.day += 1
            
            # Check game over
            if self.player.health <= 0:
                self.state = GameState.GAME_OVER
            
            # Update camera
            self.update_camera()
    
    def draw_world(self):
        # Draw background grass tiles
        start_x = int(self.camera_x // TILE_SIZE) * TILE_SIZE
        start_y = int(self.camera_y // TILE_SIZE) * TILE_SIZE
        end_x = start_x + SCREEN_WIDTH + TILE_SIZE
        end_y = start_y + SCREEN_HEIGHT + TILE_SIZE
        
        for x in range(start_x, end_x, TILE_SIZE):
            for y in range(start_y, end_y, TILE_SIZE):
                screen_x = x - self.camera_x
                screen_y = y - self.camera_y
                self.screen.blit(self.assets.get_image('grass'), (screen_x, screen_y))
        
        # Draw resources
        for resource in self.resources:
            if resource.amount > 0:
                screen_x = resource.position.x - self.camera_x
                screen_y = resource.position.y - self.camera_y
                
                if -TILE_SIZE < screen_x < SCREEN_WIDTH and -TILE_SIZE < screen_y < SCREEN_HEIGHT:
                    image = self.assets.get_image(resource.type)
                    self.screen.blit(image, (screen_x, screen_y))
                    
                    # Draw resource amount indicator
                    if resource.amount < resource.max_amount:
                        amount_text = self.small_font.render(str(resource.amount), True, WHITE)
                        self.screen.blit(amount_text, (screen_x + 2, screen_y + 2))
        
        # Draw animals
        for animal in self.animals:
            screen_x = animal.position.x - self.camera_x
            screen_y = animal.position.y - self.camera_y
            
            if -TILE_SIZE < screen_x < SCREEN_WIDTH and -TILE_SIZE < screen_y < SCREEN_HEIGHT:
                image = self.assets.get_image(animal.type)
                self.screen.blit(image, (screen_x, screen_y))
                
                # Draw health bar for damaged animals
                if animal.health < animal.get_max_health():
                    bar_width = 40
                    bar_height = 4
                    health_ratio = animal.health / animal.get_max_health()
                    pygame.draw.rect(self.screen, RED, 
                                   (screen_x + 12, screen_y - 8, bar_width, bar_height))
                    pygame.draw.rect(self.screen, GREEN, 
                                   (screen_x + 12, screen_y - 8, bar_width * health_ratio, bar_height))
        
        # Draw player
        player_screen_x = self.player.position.x - self.camera_x
        player_screen_y = self.player.position.y - self.camera_y
        player_image = self.assets.get_image('player')
        self.screen.blit(player_image, (player_screen_x, player_screen_y))
    
    def draw_ui(self):
        # Create semi-transparent UI background
        ui_surface = pygame.Surface((SCREEN_WIDTH, 120))
        ui_surface.set_alpha(200)
        ui_surface.fill(BLACK)
        self.screen.blit(ui_surface, (0, 0))
        
        # Health bar
        self.draw_stat_bar(10, 10, 200, 20, self.player.health, self.player.max_health, 
                          RED, GREEN, "Health")
        
        # Hunger bar
        self.draw_stat_bar(10, 35, 200, 20, self.player.hunger, 100, 
                          BROWN, YELLOW, "Hunger")
        
        # Thirst bar
        self.draw_stat_bar(10, 60, 200, 20, self.player.thirst, 100, 
                          GRAY, LIGHT_BLUE, "Thirst")
        
        # Energy bar
        self.draw_stat_bar(10, 85, 200, 20, self.player.energy, 100, 
                          (64, 64, 64), (255, 255, 0), "Energy")
        
        # Time and day
        time_text = self.font.render(f"Day {self.day} - {int(self.time_of_day):02d}:00", True, WHITE)
        self.screen.blit(time_text, (SCREEN_WIDTH - 150, 10))
        
        # Weather
        weather_text = self.font.render(f"Weather: {self.weather.title()}", True, WHITE)
        self.screen.blit(weather_text, (SCREEN_WIDTH - 150, 35))
        
        # Quick inventory display
        self.draw_quick_inventory()
        
        # Controls help
        if not self.show_inventory and not self.show_crafting:
            self.draw_controls_help()
        
        # Inventory display
        if self.show_inventory:
            self.draw_inventory()
        
        # Crafting display
        if self.show_crafting:
            self.draw_crafting()
    
    def draw_stat_bar(self, x, y, width, height, current, maximum, bg_color, fg_color, label):
        # Background
        pygame.draw.rect(self.screen, bg_color, (x, y, width, height))
        # Foreground
        ratio = current / maximum if maximum > 0 else 0
        pygame.draw.rect(self.screen, fg_color, (x, y, width * ratio, height))
        # Border
        pygame.draw.rect(self.screen, WHITE, (x, y, width, height), 2)
        # Text
        text = self.font.render(f"{label}: {int(current)}/{int(maximum)}", True, WHITE)
        self.screen.blit(text, (x + width + 10, y))
    
    def draw_quick_inventory(self):
        # Quick inventory icons
        quick_items = ['wood', 'stone', 'berries', 'water', 'meat']
        start_x = SCREEN_WIDTH - 300
        start_y = 60
        
        for i, item in enumerate(quick_items):
            x = start_x + i * 35
            icon = self.assets.get_image(f'{item}_icon')
            self.screen.blit(icon, (x, start_y))
            
            # Item count
            count = self.player.inventory.items.get(item, 0)
            if count > 0:
                count_text = self.small_font.render(str(count), True, WHITE)
                self.screen.blit(count_text, (x + 20, start_y + 20))
    
    def draw_controls_help(self):
        controls = [
            "WASD: Move  E: Harvest  F: Attack",
            "I: Inventory  C: Crafting  1/2/3: Consume",
            "ESC: Pause"
        ]
        
        for i, control in enumerate(controls):
            text = self.small_font.render(control, True, WHITE)
            self.screen.blit(text, (10, SCREEN_HEIGHT - 60 + i * 20))
    
    def draw_inventory(self):
        # Draw inventory background
        inv_rect = pygame.Rect(SCREEN_WIDTH - 350, 130, 330, 450)
        pygame.draw.rect(self.screen, BLACK, inv_rect)
        pygame.draw.rect(self.screen, WHITE, inv_rect, 3)
        
        # Title
        title = self.font.render("INVENTORY", True, WHITE)
        self.screen.blit(title, (inv_rect.x + 10, inv_rect.y + 10))
        
        # Capacity
        total_items = sum(self.player.inventory.items.values())
        capacity_text = self.small_font.render(f"Capacity: {total_items}/{self.player.inventory.max_capacity}", True, WHITE)
        self.screen.blit(capacity_text, (inv_rect.x + 10, inv_rect.y + 35))
        
        # Items with icons
        y_offset = 60
        for item, amount in self.player.inventory.items.items():
            if amount > 0:
                # Item icon
                icon = self.assets.get_image(f'{item}_icon')
                if item in ['axe', 'pickaxe', 'spear']:
                    icon = self.assets.get_image(item)
                self.screen.blit(icon, (inv_rect.x + 10, inv_rect.y + y_offset))
                
                # Item text
                text = self.font.render(f"{item.replace('_', ' ').title()}: {amount}", True, WHITE)
                self.screen.blit(text, (inv_rect.x + 40, inv_rect.y + y_offset + 5))
                y_offset += 35
    
    def draw_crafting(self):
        # Draw crafting background
        craft_rect = pygame.Rect(50, 130, 400, 450)
        pygame.draw.rect(self.screen, BLACK, craft_rect)
        pygame.draw.rect(self.screen, WHITE, craft_rect, 3)
        
        # Title
        title = self.font.render("CRAFTING RECIPES", True, WHITE)
        self.screen.blit(title, (craft_rect.x + 10, craft_rect.y + 10))
        
        # Instructions
        instruction = self.small_font.render("Press Q/W/E to craft when materials available", True, WHITE)
        self.screen.blit(instruction, (craft_rect.x + 10, craft_rect.y + 35))
        
        # Recipes
        recipes = {
            'axe': {'wood': 3, 'stone': 2, 'key': 'Q'},
            'pickaxe': {'wood': 2, 'stone': 3, 'key': 'W'},
            'spear': {'wood': 2, 'stone': 1, 'key': 'E'}
        }
        
        y_offset = 70
        for item, recipe in recipes.items():
            # Check if craftable
            can_craft = all(self.player.inventory.has_item(mat, amt) 
                          for mat, amt in recipe.items() if mat != 'key')
            color = GREEN if can_craft else RED
            
            # Item icon
            icon = self.assets.get_image(item)
            self.screen.blit(icon, (craft_rect.x + 10, craft_rect.y + y_offset))
            
            # Item name and key
            text = self.font.render(f"{item.title()} ({recipe['key']})", True, color)
            self.screen.blit(text, (craft_rect.x + 50, craft_rect.y + y_offset))
            y_offset += 25
            
            # Requirements
            for material, amount in recipe.items():
                if material != 'key':
                    has_amount = self.player.inventory.items.get(material, 0)
                    req_color = GREEN if has_amount >= amount else RED
                    req_text = self.small_font.render(f"  {material}: {has_amount}/{amount}", True, req_color)
                    self.screen.blit(req_text, (craft_rect.x + 20, craft_rect.y + y_offset))
                    y_offset += 18
            
            y_offset += 15
    
    def draw_menu(self):
        # Background
        self.screen.fill((25, 25, 112))  # Midnight blue
        
        # Title with shadow effect
        title_shadow = self.big_font.render("WILDERNESS SURVIVAL", True, BLACK)
        title = self.big_font.render("WILDERNESS SURVIVAL", True, WHITE)
        title_rect = title.get_rect(center=(SCREEN_WIDTH//2, SCREEN_HEIGHT//2 - 100))
        self.screen.blit(title_shadow, (title_rect.x + 3, title_rect.y + 3))
        self.screen.blit(title, title_rect)
        
        # Subtitle
        subtitle = self.font.render("Enhanced Edition with Graphics & Sound", True, YELLOW)
        subtitle_rect = subtitle.get_rect(center=(SCREEN_WIDTH//2, SCREEN_HEIGHT//2 - 60))
        self.screen.blit(subtitle, subtitle_rect)
        
        # Start instruction
        start_text = self.font.render("Press SPACE to start your survival journey", True, WHITE)
        start_rect = start_text.get_rect(center=(SCREEN_WIDTH//2, SCREEN_HEIGHT//2))
        self.screen.blit(start_text, start_rect)
        
        # Game features
        features = [
            "🌲 Gather resources from trees, rocks, and bushes",
            "🔨 Craft tools to improve efficiency",
            "🦌 Hunt animals for food and defend against wolves",
            "💧 Manage hunger, thirst, and health to survive",
            "🌅 Experience dynamic day/night cycles"
        ]
        
        for i, feature in enumerate(features):
            text = self.font.render(feature, True, WHITE)
            text_rect = text.get_rect(center=(SCREEN_WIDTH//2, SCREEN_HEIGHT//2 + 50 + i * 30))
            self.screen.blit(text, text_rect)
    
    def draw_pause(self):
        # Draw semi-transparent overlay
        overlay = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT))
        overlay.set_alpha(128)
        overlay.fill(BLACK)
        self.screen.blit(overlay, (0, 0))
        
        # Pause menu background
        menu_rect = pygame.Rect(SCREEN_WIDTH//2 - 200, SCREEN_HEIGHT//2 - 100, 400, 200)
        pygame.draw.rect(self.screen, BLACK, menu_rect)
        pygame.draw.rect(self.screen, WHITE, menu_rect, 3)
        
        pause_text = self.big_font.render("PAUSED", True, WHITE)
        pause_rect = pause_text.get_rect(center=(SCREEN_WIDTH//2, SCREEN_HEIGHT//2 - 50))
        self.screen.blit(pause_text, pause_rect)
        
        resume_text = self.font.render("Press ESC to resume", True, WHITE)
        resume_rect = resume_text.get_rect(center=(SCREEN_WIDTH//2, SCREEN_HEIGHT//2))
        self.screen.blit(resume_text, resume_rect)
        
        quit_text = self.font.render("Press Q to quit", True, WHITE)
        quit_rect = quit_text.get_rect(center=(SCREEN_WIDTH//2, SCREEN_HEIGHT//2 + 30))
        self.screen.blit(quit_text, quit_rect)
    
    def draw_game_over(self):
        self.screen.fill((139, 0, 0))  # Dark red
        
        # Game over text with shadow
        game_over_shadow = self.big_font.render("GAME OVER", True, BLACK)
        game_over_text = self.big_font.render("GAME OVER", True, WHITE)
        game_over_rect = game_over_text.get_rect(center=(SCREEN_WIDTH//2, SCREEN_HEIGHT//2 - 100))
        self.screen.blit(game_over_shadow, (game_over_rect.x + 3, game_over_rect.y + 3))
        self.screen.blit(game_over_text, game_over_rect)
        
        # Survival stats
        survived_text = self.font.render(f"You survived {self.day} days", True, WHITE)
        survived_rect = survived_text.get_rect(center=(SCREEN_WIDTH//2, SCREEN_HEIGHT//2 - 50))
        self.screen.blit(survived_text, survived_rect)
        
        # Final stats
        stats = [
            f"Resources gathered: {sum(self.player.inventory.items.values())}",
            f"Tools crafted: {self.player.inventory.items['axe'] + self.player.inventory.items['pickaxe'] + self.player.inventory.items['spear']}",
            f"Final health: {int(self.player.health)}"
        ]
        
        for i, stat in enumerate(stats):
            text = self.font.render(stat, True, WHITE)
            text_rect = text.get_rect(center=(SCREEN_WIDTH//2, SCREEN_HEIGHT//2 - 10 + i * 25))
            self.screen.blit(text, text_rect)
        
        # Restart instructions
        restart_text = self.font.render("Press R to restart, Q to quit", True, YELLOW)
        restart_rect = restart_text.get_rect(center=(SCREEN_WIDTH//2, SCREEN_HEIGHT//2 + 80))
        self.screen.blit(restart_text, restart_rect)
    
    def restart_game(self):
        self.__init__()
    
    def run(self):
        running = True
        
        while running:
            dt = self.clock.tick(FPS) / 1000.0  # Delta time in seconds
            
            running = self.handle_input()
            self.update(dt)
            
            # Draw everything
            if self.state == GameState.MENU:
                self.draw_menu()
            elif self.state == GameState.PLAYING:
                self.draw_world()
                self.draw_ui()
            elif self.state == GameState.PAUSED:
                self.draw_world()
                self.draw_ui()
                self.draw_pause()
            elif self.state == GameState.GAME_OVER:
                self.draw_game_over()
            
            pygame.display.flip()
        
        pygame.quit()
        sys.exit()

if __name__ == "__main__":
    game = Game()
    game.run()