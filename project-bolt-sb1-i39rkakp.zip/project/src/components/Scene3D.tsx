import React, { useRef } from 'react';
import { Canvas } from '@react-three/fiber';
import { OrbitControls, useGLTF, Environment, Float } from '@react-three/drei';
import { motion } from 'framer-motion-3d';

function WaterBottle({ position = [0, 0, 0] }) {
  const { scene } = useGLTF('https://vazxmixjsiawhamofees.supabase.co/storage/v1/object/public/models/water-bottle/model.gltf');
  return <primitive object={scene} position={position} scale={2} />;
}

function PlasticBag({ position = [2, 0, 0] }) {
  const { scene } = useGLTF('https://vazxmixjsiawhamofees.supabase.co/storage/v1/object/public/models/plastic-bag/model.gltf');
  return <primitive object={scene} position={position} scale={1.5} />;
}

export default function Scene3D() {
  return (
    <div className="h-[400px] w-full">
      <Canvas camera={{ position: [0, 2, 5], fov: 45 }}>
        <ambientLight intensity={0.5} />
        <pointLight position={[10, 10, 10]} />
        
        <Float
          speed={1.5}
          rotationIntensity={1}
          floatIntensity={1}
        >
          <WaterBottle />
          <PlasticBag />
        </Float>

        <Environment preset="sunset" />
        <OrbitControls enableZoom={false} />
      </Canvas>
    </div>
  );
}